#include <iostream>
#include <cmath>
using namespace std;
int main() {
    const int N = 4, M = 3;
    int i, j, n, k;
    int A[4][3];
    int base = 1;
    bool teres = false;
    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            cin >> A[i][j];
        }
    }
    cout << endl;
    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            if (A[i][j] > 0) {
                cout << A[i][j] << " ";
                base *= A[i][j];
                teres = true;
            }
        }
    }
    if (teres) {
        cout << endl << base;
    }
    else {
        cout << "HeT nolowuTelHux";
    }
}
